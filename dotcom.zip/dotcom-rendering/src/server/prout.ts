// this should get overwritten in CI (see .github/workflows/container.yml)
export const GIT_COMMIT_HASH = 'LOCAL';
