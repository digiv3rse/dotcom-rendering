import { transformDots } from './transformDots';

export const enhanceStandfirst = (html: string): string => transformDots(html);
