export const clearFix = `
    :after {
        content: '';
        display: table;
        clear: both;
    }
`;
