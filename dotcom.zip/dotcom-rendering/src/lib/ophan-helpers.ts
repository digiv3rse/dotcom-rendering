export const nestedOphanComponents = (...components: string[]): string =>
	components.join(' : ');
