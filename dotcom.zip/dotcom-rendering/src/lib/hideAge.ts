export const hideAge = [
	'Newsletters',
	'Showcase',
	'How to listen to Podcasts',
	'Get in touch',
];
