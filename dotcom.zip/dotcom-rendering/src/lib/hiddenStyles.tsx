import { css } from '@emotion/react';

export const hiddenStyles = css`
	&.hidden {
		display: none;
	}
`;
