export const Four = () => (
	<svg width="31" height="40" xmlns="http://www.w3.org/2000/svg">
		<path
			d="M12.5 40v-1l4.3-1.3v-9.2H0v-1L18.7 0h8.1v27.4H31v1.1h-4.2v9.2l3.7 1.4v.9h-18zm-11-12.6h15.3v-22h-.3l-15 21.8v.2z"
			fillRule="evenodd"
		/>
	</svg>
);
