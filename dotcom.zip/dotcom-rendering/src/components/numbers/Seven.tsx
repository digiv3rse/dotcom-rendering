export const Seven = () => (
	<svg width="28" height="40" xmlns="http://www.w3.org/2000/svg">
		<path
			d="M3.4 40h11L28 6V0H.6L0 12.3h1.1L3 7.5h23v.3z"
			fillRule="evenodd"
		/>
	</svg>
);
