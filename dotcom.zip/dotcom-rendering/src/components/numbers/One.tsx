export const One = () => (
	<svg width="21" height="40" xmlns="http://www.w3.org/2000/svg">
		<path
			d="M0 40h21v-1l-5.4-1.6V0h-4.3L.1 5.4v1.3l5.5-1.4v32.1L0 39.1z"
			fillRule="evenodd"
		/>
	</svg>
);
