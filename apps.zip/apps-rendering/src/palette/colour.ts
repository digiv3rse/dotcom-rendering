// ----- Types ----- //

type Colour = string;

// ----- Exports ----- //

export type { Colour };
