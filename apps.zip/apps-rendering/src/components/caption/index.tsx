import Caption from './caption';

export default Caption;
