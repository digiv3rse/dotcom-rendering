export const App = process.env.App ?? 'mobile-apps-rendering';
export const Stack = process.env.Stack ?? 'mobile';
export const Stage = process.env.Stage ?? 'CODE';
export const Region = process.env.AWS_REGION ?? 'eu-west-1';
